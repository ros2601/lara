<html>
<head>
    <title>Laravel 9 Custom Auth Login and Registration</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container" style="padding:50px;">
    <?php echo $__env->yieldContent('content'); ?>
</div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/custom-login/resources/views/layout.blade.php ENDPATH**/ ?>