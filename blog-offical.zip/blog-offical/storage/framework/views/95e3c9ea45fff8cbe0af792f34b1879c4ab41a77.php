<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('http://localhost/laravel/blog/resources/css/app.css')); ?>">
<!-- ---------------------------------------------------------------------------------------------------- -->

<?php if(isset($product)): ?>
<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container d-flex justify-content-center" style="text-align:center;">
    <div class="col-md-12 mt-5 card2">

<form action="<?php echo e(url('detail/'.$row->id)); ?>" method="post" > 
<?php echo e(csrf_field()); ?>

	<a href="<?php echo e(url('detail/'.$row->id)); ?>"><img src="storage/blogs/<?php echo e($row->image); ?>"></a>
    <b style="font-size:20px; color:black; margin-left:100px;"><?php echo e($row->title); ?></b>
    </div>
</div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- ---------------------------------------------------------------------------------------------------- -->
<!-- ---------------------------------------------------------------------------------------------------- -->

<?php if(isset($findrec)): ?>
<?php $__currentLoopData = $findrec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container d-flex justify-content-center" style="text-align:center;">
    <div class="col-md-12 mt-5 card2">

<form action="<?php echo e(url('detail/'.$row->id)); ?>" method="post" > 
<?php echo e(csrf_field()); ?>

	<a href="<?php echo e(url('detail/'.$row->id)); ?>"><img src="storage/blogs/<?php echo e($row->image); ?>"></a>
    <b style="font-size:20px; color:black; margin-left:100px;"><?php echo e($row->title); ?></b>
    </div>
</div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/custom-login/resources/views/home.blade.php ENDPATH**/ ?>