<?php echo $__env->make('head', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('http://localhost/laravel/blog/resources/css/app.css')); ?>">
<!-- ---------------------------------------------------------------------------------------------------- -->

<?php if(isset($product)): ?>
<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container d-flex justify-content-center" style="text-align:center;">
    <div class="col-md-12 mt-5 card2">

<form action="<?php echo e(url('detail/'.$row->id)); ?>" method="post" > 
<?php echo e(csrf_field()); ?>

	<a href="<?php echo e(url('detail/'.$row->id)); ?>"><img src="storage/images/<?php echo e($row->image); ?>" height=200px width=300px></a>
    <b style="font-size:20px; color:black; margin-left:100px;"><?php echo e($row->title); ?></b>
    <!-- <button type="button" class="btn btn-dark">Read More</button> -->
    </div>
</div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>
<!-- ---------------------------------------------------------------------------------------------------- -->
<!-- ---------------------------------------------------------------------------------------------------- -->

<?php if(isset($findrec)): ?>
<?php $__currentLoopData = $findrec; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

<div class="container d-flex justify-content-center" style="text-align:center;">
    <div class="col-md-12 mt-5 card2">

<form action="<?php echo e(url('detail/'.$row->id)); ?>" method="post" > 
<?php echo e(csrf_field()); ?>

	<a href="<?php echo e(url('detail/'.$row->id)); ?>"><img src="storage/images/<?php echo e($row->image); ?>" height=200px width=300px></a>
    <b style="font-size:20px; color:black; margin-left:100px;"><?php echo e($row->title); ?></b>
    </div>
</div>
</form>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?>

<!-- ---------------------------------------------------------------------------------------------------- -->

<?php if(isset($user)): ?>
<br/><h2 style="color:black; margin-left:40%; font-weight:bold; font-family:cursive; text-shadow:0 1px 2px grey; text-decoration:underline;">Posts by <?php echo e(Auth::user()->name); ?> </h2>  
<?php $__currentLoopData = $user; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<div class="container d-flex justify-content-center" style="text-align:center;">
    <div class="col-md-12 mt-5 card2">
      
            <form action="<?php echo e(url('detail/'.$row->id)); ?>" method="post" > 
            <?php echo e(csrf_field()); ?>

	            <a href="<?php echo e(url('detail/'.$row->id)); ?>"><img src="storage/images/<?php echo e($row->image); ?>" height=200px width=300px></a>
                <b style="font-size:20px; color:black; margin-left:100px;"><?php echo e($row->title); ?></b>
            </form>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php endif; ?><?php /**PATH /opt/lampp/htdocs/laravel/blog-offical/resources/views/home.blade.php ENDPATH**/ ?>