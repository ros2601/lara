<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
                      
class addpage extends Model
{
    use HasFactory;
    protected $table="addpage";
    public $timestamps=false;
}                         