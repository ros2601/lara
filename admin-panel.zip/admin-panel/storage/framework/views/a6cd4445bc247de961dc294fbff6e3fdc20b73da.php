<html>

<head>
    <title>
    Add product category
    </title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('http://localhost/admin-panel/resources/css/login.css')); ?>">
    <link rel="stylesheet" type="text/css"  href="<?php echo e(asset('http://localhost/admin-panel/resources/css/header.css')); ?>" >
</head>

<body>
<!----------------------------------->
<div class="container1">
    <div class="subcontainer1">
    <image src="<?php echo e(asset('logo.PNG')); ?>" />
        <button><a href="<?php echo e(url('/logout')); ?>">Logout</a></button>
    </div>
</div> 
<!----------------------------------->
<div class="container2">
    <div class="subcontainer2">
    <?php
       echo date('d-m-Y');
       ?>
    </div>   
</div>
<!----------------------------------->


</div>

</body>
</html><?php /**PATH /opt/lampp/htdocs/all-projects/admin-panel/resources/views/header.blade.php ENDPATH**/ ?>