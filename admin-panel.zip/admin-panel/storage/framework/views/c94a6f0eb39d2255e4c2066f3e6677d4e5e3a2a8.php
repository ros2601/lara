<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!----------------------------------->
<div class="maincontainer">
    <div class="innerconatiner">

        <div class="left-section">
            <?php echo $__env->make('left', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div> 

        <div class="right-section">
            <div class="right">
                    <div class="heading">
                    <h2>Product Manager</h2>
                    </div>

                  
            <div class="addpage">
            <div class="sea">Add Product</div><br/>
            
            <?php if(@isset($findrec[0])): ?>
                <form action="<?php echo e(url('p_editdata/'.$findrec[0]->id)); ?>" method="post" enctype="multipart/form-data">
            <?php else: ?>
                <form method="post" enctype="multipart/form-data" action="<?php echo e(url('/add-product')); ?>" > 
            <?php endif; ?>

                <?php echo e(csrf_field()); ?>

                
                <div class="product">
                    <table>
                        <tr>
                            <td></td>
                            <td>
                            <select name="c_id">Choose Category
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                              <option value="<?php echo e($row->name); ?>">  <?php echo e($row->name); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                           </td>
                   
                        </tr>

                        <tr>
                            <td class="t1">Name*</td>
                            <td><input type="text" name="name" value="<?php echo e(isset($findrec[0]->name) ? $findrec[0]->name:""); ?>"></td>
                        </tr>
                        <tr>
                            <td class="t1">Price</td>
                            <td><input type="text" name="price" value="<?php echo e(isset($findrec[0]->price) ? $findrec[0]->price:""); ?>"></td>
                        </tr>
                
                        <tr>
                            <td class="t1"> Description</td>
                            <td ><input type="text" name="description" rows="5" cols="55" value="<?php echo e(isset($findrec[0]->description) ? $findrec[0]->description:""); ?>"></td>
                        </tr>

                        <tr>
                            <td class="t1">Image</td>
                            <td><input type="file" name="image" value="<?php echo e(isset($findrec[0]->image) ? $findrec[0]->image:""); ?>">Choose any picture </td>
                            
                        </tr>
        
                    </table>

                    <div class="btns" >
                         <input type="submit" name="save" value="Save" />
                         <input type="button" name="cancel" value="Cancel" />  
                    </div>
               </form>  
            </div>
            </div>
        </div>
    </div>
</div>

</div>
<div class="container4"></div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/laravel/admin-panel/resources/views/productadd.blade.php ENDPATH**/ ?>