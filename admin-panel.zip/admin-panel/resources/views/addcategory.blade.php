@include('header')

<!----------------------------------->
<div class="maincontainer">
    <div class="innercontainer">
    @include('left')
        <div class="right-section">
            <div class="right">
                <div class="heading">
                    <h2>Category Manager</h2>
                </div>
            
            <div class="addpage">
                <div class="sea">Add Category</div><br/>
                    @if(@isset($findrec[0]))
                        <form action="{{url('c_editdata/'.$findrec[0]->id)}}" method="post">
                    @endif
                        <form method="post" action="{{url('/add-category')}}" > 
                        {{csrf_field()}}
                            <table>
                                <tr>
                                    <td class="t1">Name*</td>
                                    <td><input type="text" name="name" value="{{isset($findrec[0]->name) ? $findrec[0]->name:""}}"></td>
                               </tr>
                            </table>
                            <div class="btns" >
                                <input type="submit" name="save" value="Save" />
                                <input type="button" name="cancel" value="Cancel" />  
                            </div>
                        </form>  
                </div>
            </div>
    </div>
</div>
</div>
    <div class="container4"></div>
</body>
</html>