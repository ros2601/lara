@include('header')

<!----------------------------------->
<div class="maincontainer">
    <div class="innerconatiner">

        <div class="left-section">
            @include('left')
        </div> 

        <div class="right-section">
            <div class="right">
                    <div class="heading">
                        <h2>Product Manager</h2>
                    </div>
                        <p>  This section displays the Products</p><hr size="1"/>

                    <div class="link1">
                       <a href="{{url('/addproduct')}}" >Click here</a> to add <a href="{{url('/addproduct')}}">New Product</a><br/>
                    </div>

                    <div class="sea">Search</div>
                    <div class="sea-table">

                            <form method="post" action="{{url('/psearch-record')}}">
                                {{csrf_field()}}
                                <table width=100%>
                                   <tr>
                                       <td>Search By Product Name </td>
                                       <td><input type="text" name="text"><button name="submit" value="Search">Search</button></td>
                                   </tr>
                                     </table>
                            </form>
                    </div>
                    <br/><br/>
                     
                    <div class="table">
                    
                       <table width=100%   border=1px solid black>
                         <tr>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Price</th>
                            <th>Image</th>
                            <th>Description</th>
                            <th>Edit</th>
                            <th>Delete</th>
                         </tr> 

                         @foreach($product as $row)
                         <tr>
                            <td>{{$row->name}}</td>
                            <td>{{$row->c_id}}</td>
                            <td>{{$row->price}}</td>
                            <td><img src="uploads/{{$row->image}}" width="80%" height="80px"></td>
                            <td>{{$row->description}}</td>
                            <td><a href="{{'p_editpage/'.$row->id}}" ><img src="edit.PNG" width=18px height=18px></a></td>
                            <td><a href="{{'p_deletedata/'.$row->id}}" ><img src="delete.jpeg" width=18px height=18px></a></td>
                         </tr>
                        @endforeach 

                       </table>
                    </div>
                        {{$product->links()}}
                 </div>
</div>
            </div>
        </div>
    </div>
</div>

     
<div class="container4"></div>
</body>

</html>