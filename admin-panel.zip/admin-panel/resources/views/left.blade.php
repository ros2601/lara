<div class="left-section">
<div class="left">
    <br/>
    <div class="content1">
        <h3><a href="{{url('/summarypage')}}">Page Summary</a></h3><hr/>
        <p><a href="{{url('/addpage')}}">Add Page</a></p><hr/>
        <h3><a href="{{url('/summarycat')}}">Category Summary</a></h3><hr/>
        <p><a href="{{url('/addcat')}}">Add Category</a></p><hr/>
        <h3><a href="{{url('/summaryproduct')}}">Product Summary</a></h3><hr/>
        <p><a href="{{url('/addproduct')}}">Add Product</a></p><hr/>
        <h3><a href="{{url('/password')}}">Change Password</a></h3><hr/>
        <p>Login Information<br/>Username : <?php $name = session()->get('user_session');
        echo $name;?>   </p>
     </div> 
</div>
</div> 