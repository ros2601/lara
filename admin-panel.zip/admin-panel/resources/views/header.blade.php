<html>

<head>
    <title>
    Add product category
    </title>
    <link rel="stylesheet" type="text/css" href="{{asset('http://localhost/laravel/admin-panel/resources/css/login.css')}}">
    <link rel="stylesheet" type="text/css"  href="{{asset('http://localhost/laravel/admin-panel/resources/css/header.css')}}" >
</head>

<body>
<!----------------------------------->
<div class="container1">
    <div class="subcontainer1">
    <image src="{{asset('logo.PNG')}}" />
        <button><a href="{{url('/logout')}}">Logout</a></button>
    </div>
</div> 
<!----------------------------------->
<div class="container2">
    <div class="subcontainer2">
    <?php
       echo date('d-m-Y');
       ?>
    </div>   
</div>
<!----------------------------------->