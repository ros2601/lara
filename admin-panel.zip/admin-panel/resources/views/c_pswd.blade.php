@include('header')

<div class="maincontainer">
    <div class="innerconatiner">
        @include('left')
        <div class="right-section">
            <div class="right">
                <div class="heading">
                <h2>Change Password</h2>
            </div><br/>
                    
            <div class="addpage">
                <p>Change Password</p>
                <form method="post" action="{{url('/password-change')}}" > 
                {{csrf_field()}}
                    <table>
                        <tr>
                            <td class="t1">Enter Old Password</td>
                            <td><input type="password" name="opassword" ></td>
                        </tr>
                        <tr>
                            <td class="t1">Enter New Password</td>
                            <td><input type="password" name="npassword"></td>
                        </tr>
                
                        <tr>
                            <td class="t1">Confirm New Password</td>
                            <td><input type="password" name="cpassword"></td>
                        </tr>

                    </table>

                    <div class="btns" >
                         <input type="submit" name="save" value="Save" />
                         <input type="button" name="cancel" value="Cancel" />  
                    </div>

               </form>  
            </div>
        </div>
    </div>
</div>

</div>
<div class="container4"></div>
</body>
</html>