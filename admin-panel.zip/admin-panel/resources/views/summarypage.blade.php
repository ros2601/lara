@include('header')

<!----------------------------------->
<div class="maincontainer">
    <div class="innerconatiner">

        <div class="left-section">
            @include('left')
        </div> 

        <div class="right-section">
            <div class="right">
                    <div class="heading">
                        <h2>Page Manager</h2>
                    </div>
                        <p>  This section displays the list of Pages</p><hr size="1"/>

                    <div class="link1">
                       <a href="{{url('/addpage')}}" >Click here</a> to create <a href="{{url('/addpage')}}">New Page</a><br/>
                    </div>

                    <div class="sea">Search</div>
                    <div class="sea-table">

                            <form method="post" action="{{url('/search-record')}}">
                                {{csrf_field()}}
                                <table width=100%>
                                   <tr>
                                       <td>Search By Page Name </td>
                                       <td><input type="text" name="text"><button name="submit" value="Search">Search</button></td>
                                   </tr>
                                     </table>
                            </form>
                    </div>
                    <br/><br/>
                     
                    <div class="table">
                    
                       <table width=100%   border=1px solid black>
                         <tr>
                            <th>Name</th>
                            <th>Content</th>
                            <th>Status</th>
                            <th>Edit</th>
                            <th>Delete</th>
                         </tr> 
                        
                         @foreach($data as $row)
                         <tr>
                            <td>{{$row->name}}</td>
                            <td>{{$row->content}}</td>
                            <td>{{$row->status}}</td>
                            <td><a href="{{'edit_page/'.$row->id}}" ><img src="edit.PNG" width=18px height=18px></a></td>
                            <td><a href="{{'delete_data/'.$row->id}}" ><img src="delete.jpeg" width=18px height=18px></a></td>
                         </tr>
                        @endforeach

                       </table>
                    </div>
                        {{$data->links()}}
                 </div>
</div>
            </div>
        </div>
    </div>
</div>

     
<div class="container4"></div>
</body>

</html>