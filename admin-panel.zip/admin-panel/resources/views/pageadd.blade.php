@include('header')
<!----------------------------------->
<div class="maincontainer">
    <div class="innerconatiner">

        <div class="left-section">
             @include('left')
        </div> 

        <div class="right-section">
            <div class="right">
                    <div class="heading">
                    <h2>Page Manager</h2>
                    </div><br/>
                  
            <div class="addpage">
            
            <div class="sea">Add page</div>   <br/>
            @if(@isset($findrec[0]))
                <form action="{{url('editdata/'.$findrec[0]->id)}}" method="post">
            @else
            @endif
                <form method="post" action="{{url('/add-page')}}" > 
                {{csrf_field()}}
                    <table>
                        <tr>
                            <td class="t1">Name*</td>
                            <td><input type="text" name="name" value="{{isset($findrec[0]->name) ? $findrec[0]->name:""}}"></td>
                        </tr>
                        <tr>
                                <td class="t1"> Content</td>
                                <td ><textarea name="content" class="tinymce" value="{{isset($findrec[0]->content) ? $findrec[0]->content:""}}" rows="15" cols="55" ></textarea></td>
                        </tr>

                        <tr>
                            <td class="t1">Status</td>
                            <td><input type="checkbox" name="status" ></td>
                        </tr>
        
                    </table>

                    <div class="btns" >
                         <input type="submit" name="save" value="Save" />
                         <input type="button" name="cancel" value="Cancel" />  
                    </div>

               </form>  
            </div>
        </div>
    </div>
</div>

</div>
<div class="container4"></div>
</body>
</html>