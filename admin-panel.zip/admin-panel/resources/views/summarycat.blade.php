@include('header')


<!----------------------------------->
<div class="maincontainer">
    <div class="innerconatiner">

        <div class="left-section">
            <div class="left">
                @include('left')
            </div>
        </div> 

        <div class="right-section">
            <div class="right">
                    <div class="heading">
                    <h2>Category Manager</h2>
                    </div>
                       <p>  This section displays the list of Categories</p><hr size="1"/>

                    <div class="link1">
                       <a href="{{url('/addcat')}}" >Click here</a> to add <a href="{{url('/addcat')}}">New Category</a><br/>
                    </div>

                    <div class="displaypage">

                       <div class="sea">Search</div>
                           <div class="sea-table">

                           <form method="post" action="{{url('/c_search-record')}}">
                                {{csrf_field()}}
                                <table width=100%>
                                <tr>
                                       <td>Search By Category </td>
                                       <td><input type="text" name="text"><button name="submit" value="Search">Search</button></td>
                                   </tr>
                                 </table>
                            </form>
                           </div>
                       </div>
                       <br/><br/>
                       <div class="table">
                       
                       <table width=100%   border=1px solid black>
                         <tr>
                            <th>Name</th>
                            <th>Edit</th>
                            <th>Delete</th>
                         </tr>
                         @foreach($data as $row)
                         <tr>
                            <td>{{$row->name}}</td>
                            <td><a href="{{'c_edit_display/'.$row->id}}" ><img src="edit.PNG" width=18px height=18px></a></td>
                            <td><a href="{{'c_delete_data/'.$row->id}}" ><img src="delete.jpeg" width=18px height=18px></a></td>
                         </tr>
                        @endforeach

                       </table>
                        </div>
                        {{$data->links()}}
</div>
            </div>
        </div>
    </div>
</div>

     
<div class="container4"></div>
</body>

</html>