<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\User;
class bcontroller extends Controller
{
    public function register(Request $request)
    {
        $user=User::create([
            'name'=>$request->name,
            'email'=>$request->email,
            'password'=>\Hash::make($request->password)
        ]);  
        $token=$user->createToken('Token')->accessToken;
        return response()->json(['token'=>$token,'user'=>$user],200);
    }
    public function login(Request $request)
    {
        $data=[
            'email'=>$request->email,
            'password'=>$request->password
        ];
        if(auth()->attempt($data))
        {
            echo "Logged Successfully";
            $token=auth()->user()->CreateToken('Token')->accessToken;
            return response()->json(['token'=>$token],200);
        }
        else{
            // return response()>json(['error'=>'unauthorised'],401);
            echo "User Not Found";
        }
    }
    public function userinfo()
    {
        $user=auth()->user();
        return response()->json(['user'=>$user],200);
    }
}
