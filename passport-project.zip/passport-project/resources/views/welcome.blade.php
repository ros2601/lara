<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">

        <title>Laravel</title>
        <style>
            body {
                font-family: 'Nunito', sans-serif;
            }
        </style>
    </head>
    <body class="antialiased">
         <h1>This is project named Passport-project</h1>
         <h2>And this project contains Login and register using passport method(laravel Api) and use of postman to register and login</h2>
    </body>
</html>
