<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Casts\Attribute;
use illuminate\Support\str;
class post extends Model
{
    use HasFactory;
    public function comments()
    {
        return $this->hasMany(comment::class);
    }
    // public function title():Attribute(
    //     return Attribute:make(
    //         set:fn($value)=>[
    //             'slug'=>str:slug($value),
    //             'title'=>$value
    //         ]
    //         );
    // )
    // public static function boot()
    // {
    //     parent::boot();
    //     static::saving(function($post)
    //     {
    //         $post->slug= Str::slug($post->title);
    //     });
    //     static::deleted(function($post)
    //     {
    //         $post->comments()->delete();
    //     });
    // }
}
