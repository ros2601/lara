<?php

use Illuminate\Support\Facades\Route;
use App\Models\{
    post,comment
};

Route::get('/', function () {
    return view('welcome');
 });


Route::get('/observer', function () {
   post::whereId(1)->first()->delete();
   dd('deleted');
// return view('welcome');
});
