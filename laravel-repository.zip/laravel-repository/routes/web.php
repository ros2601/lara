<?php

use Illuminate\Support\Facades\Route;

Route::get('/', function () {
    return view('welcome');
});
Route::get('/file', function () {
    return view('file');
});
Route::get('/file',"App\Http\Controllers\bcontroller@display");
Route::post('/insert',"App\Http\Controllers\bcontroller@create");
Route::get('delete/{id}',"App\Http\Controllers\bcontroller@delete");
Route::get('edit/{id}',"App\Http\Controllers\bcontroller@edit");
Route::post('update/{id}',"App\Http\Controllers\bcontroller@update");
