<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\person;
use App\Repositories\Interfaces\PersonRepositoryInterface;
class bcontroller extends Controller
{
    private $personrepository;
    public function __construct(PersonRepositoryInterface $personrepository)
    {
        $this->personrepository=$personrepository;
    }
    //-------------------------------------------------------------------------
    public function display()
    {
        //all method name of personrepositryinterface
     $data=$this->personrepository->all();
     return view('file',compact('data'));
    }
    //--------------------------------------------------------------------------
    public function create(Request $request)
    {
        $data=$request->validate(
            [
                'name'=>'required',
                'email'=>'required'
            ]
            );
            $this->personrepository->store($data);
            return back()->withErrors(["custom_name" => "Person created Successfully !"]);
    }
    //---------------------------------------------------------------------------------
    public function edit($id)
    {
        $data=person::all();
        $findrec= $this->personrepository->find($id);
        return view('file',compact('findrec','data'));
    }
    //------------------------------------------------------------------------------
    public function update(Request $request, $id='')
    {  
        //by request->all we are passing data
       $this->personrepository->update($request->all(),$id);
       return redirect('/file')->withErrors(["custom_name" => "Record updated Successfully!"]);
    }
    //--------------------------------------------------------------------------
    public function delete($id)
    {  
        $this->personrepository->delete($id);
        return back()->withErrors(["custom_name" => "Person Deleted Successfully !"]);
    }
}
