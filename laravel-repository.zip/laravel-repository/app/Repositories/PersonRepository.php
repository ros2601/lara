<?php
namespace App\Repositories;

use App\Models\person;
use App\Repositories\Interfaces\PersonRepositoryInterface;

class PersonRepository implements PersonRepositoryInterface{
    public function all()
    {
        return person::all();
    }
    public function store($data)
    {
       person::create($data);
    }
    public function find($id)
    {
        return person::where('id',$id)->get();
    }
    public function update($data,$id)
    {
        $person=person::where('id',$id)->first();
        echo $person;
        $person->name=$data['name'];
        $person->email=$data['email'];
        $person->save();
    }
    public function delete($id)
    {
        $id= person::find($id);
        $id->delete();
    }
}