<?php

use Illuminate\Support\Facades\Route;


Route::get('/', function () {
    return view('welcome');
});
Route::get('/form', function () {
    return view('form');
});
Route::get('/contact', function () {
    return view('contact');
});
Route::get('/cart1/{user}', function () {
    return view('cart');
});
Route::get('/home', function () {
    return view('home');
});
Route::get('/detail', function () {
    return view('detail');
});
//----------------------------------------------------------------------------------------------
//For registration form
Route::post('/register-form',"App\Http\Controllers\icontroller@register");
//For login form
Route::post('/login',"App\Http\Controllers\icontroller@log");
//for logout
Route::post('/logout',"App\Http\Controllers\icontroller@logout");
//For query form
Route::post('/query-form',"App\Http\Controllers\icontroller@query");
//For contact form
Route::post('/contact-form',"App\Http\Controllers\icontroller@contact");
//-----------------------------------------------------------------------------------------------
//for displaying all products
Route::get('/home',"App\Http\Controllers\icontroller@phome");

//for cart page
Route::get('/cart1/{user}',"App\Http\Controllers\icontroller@cartproduct");

//for product display
Route::post('/show-product/{id}',"App\Http\Controllers\icontroller@showproduct");
//for product display on home page
Route::post('/home-product/{id}',"App\Http\Controllers\icontroller@homeproduct");
//for cart form
Route::post('/cart-form/{id}',"App\Http\Controllers\icontroller@addcart");
//to remove item in cart
Route::get('/remove-item/{id}',"App\Http\Controllers\icontroller@remove");
//for cart form
Route::post('/homecart-form/{id}',"App\Http\Controllers\icontroller@homeaddcart");
//for product display
Route::get('/cart2',"App\Http\Controllers\icontroller@cartproduct1");

//---------------------------------------------------------------------------------------------
//for dishwashers display
Route::get('/dishwasher',"App\Http\Controllers\icontroller@dishwashers");
//for tv display
Route::get('/tv',"App\Http\Controllers\icontroller@tvs");
//for camera display
Route::get('/camera',"App\Http\Controllers\icontroller@camera");