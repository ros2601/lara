<?php

namespace App\Http\Controllers;
use Session;
use Illuminate\Support\Facades\DB;
use Illuminate\Http\Request;
use App\Models\{business,product,query,cart,contact};

class icontroller extends Controller
{
    //for logout
    public function logout()
    {
       Session::flush();
       return redirect('form');
    }
    //ok for registeration
    public function register(Request $request)
    {
    $add= new business;
    if($request->isMethod('post'))
    {
        $add->name=$request->get('name');
        $add->email=$request->get('email');
        $add->password=$request->get('password');
        $add->save();
    }
        return back()->withErrors(["custom_name" => "Registration Successfully !"]);
    }
    //ok for login 
    public function log(Request $request)
    {
        $name = $request->get('name');
        $password = $request->get('password');
  
        echo $name;
        $count = business::select('*')
              ->where('name', $name)
              ->where('password', $password)
              ->count();
        if ($count > 0) {
              session()->put("user_session", $name);
              return redirect("/home");
        }
        return back()->withErrors(["custom" => "user Not Found!"]);
    }
    //ok for contact
    public function contact(Request $request)
    {
        $add= new contact;
        if($request->isMethod('post'))
        {
            $add->name=$request->get('name');
            $add->email=$request->get('email');
            $add->message=$request->get('message');
            $add->save();
        }
    return view("contact");
    }
  
    //ok for query
    public function query(Request $request)
    {
        $add= new query;
        if($request->isMethod('post'))
        {
            $add->name=$request->get('name');
            $add->email=$request->get('email');
            $add->review=$request->get('review');
            $add->rating=$request->get('rating');
            $add->save();
        }
        return view("detail");
    }

    //for displaying products on home page
    public function phome()
    {
        $product=product::all();
        return view('home',compact('product'));
    }
    //for displaying dishwashers page
    public function dishwashers()
    {
        $product=product::where('category','dishwasher')->get();
        return view('dishwasher',compact('product'));
    }
    //for displaying tvs page
    public function tvs()
    {
        $product=product::where('category','TVs')->get();
        return view('dishwasher',compact('product'));
    }
     //for displaying on camera page
     public function camera()
     {
         $product=product::where('category','Camera')->get();
         return view('dishwasher',compact('product'));
     }

    //for displaying a product
    public function showproduct($id)
    {
    $data=product::all();
    $findrec=product::where('id',$id)->get();
    return view('detail',compact('findrec','data'));
    }
    //-------------------------------------------------------------------------------------
    //for add a product
    public function addcart(Request $request, $id='')
    {     
        $add=product::find($id);
        echo $id;
        if($request->isMethod('post'))
        {
        $add= new cart;

        $add->name=$request->get('name');
        $add->price=$request->get('price');
        $add->quantity=$request->get('quantity');
        $add->product_id=$request->get('id');
        $add->user=$request->get('user');

        $total=$request->get('price')*$request->get('quantity');

        if(!empty($request->file('image')))
        {
        $file=$request->file('image');
        $current=uniqid(Carbon::now()->format('Ymdhs'));
        $file->getClientOriginalName();
        $file->getClientOriginalExtension();
        $fullfilename=$current.".".$file->getClientOriginalExtension();

        $destinationPath=public_path('cart');
        $file->move($destinationPath,$fullfilename);
        $add->image=$fullfilename;
        }
        $add->total=$total;
        $add->save();
       }
       return redirect('home');
    }
    //for displaying products on cartpage
    public function cartproduct(Request $request,$user='')
    {
        $cart=cart::all()->where('user',$user);
        $total=DB::table('cart')->where('user',$user)->sum('total');
        echo $total;
        if($cart)
        {
        return view('cart',compact('cart','total'));
        }
    }
    //to delete items in cart
    public function remove($id)
    {  
      $obj= cart::find($id);
      $obj->delete(); 
      return back();                                                                                                                                                                                                                                                                                                                                                                                      
    }
   
}
