<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main-categorious">
			<div class="footer">
				<div class="categorious">
					<div class="cate-heading">
						<p>CATEGORIES</p>
					</div>
					<div class="items">
					<ul>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Dishwasher</li></a>
						<a href="<?php echo e(url('/tv')); ?>"><li>tvs</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Ranges</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Computer</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Blue Ray and DVD Player</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Projectors</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Hometheater System</li></a>
						<a href="<?php echo e(url('/camera')); ?>"><li>Camera</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Camcorders</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Washer & Dryers</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Refrigerators</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Microwaves</li></a>
						</ul>
					</div>
				</div>
				<div class="contact">
					<div class="contact-us">
						<p>CONTACT US</p>
					</div>
					<div class="costomer-info">
						<div class="costomer-service">
							<br/>
							<br/>
							<br/>
							<p>Customer Service:91 7508115758</p>
							<p>Ludhiana,Punjab,INDIA</p>
							<p>Yorex Infotec.</p>
						</div>
						<hr class="hr">
						
						<div class="border">
							<div class="border-1">
								<div class="border-2">
									<p>Contact Us</p>
								</div>
								<div class="requir-info">
									<span>*Required information</span>
								</div>
								<div class="input-info">
									<div class="input-information">
								
									<form method="post" action="<?php echo e(url('contact-form')); ?>" > 
                        <?php echo e(csrf_field()); ?>

											<table class=" form">
												<tr>
													<td ><p>full Name* </p></td>
													<td><input type="text" name="name"></td>
												</tr>
												<tr>
													<td > <p>E-mail Address </p></td>
													<td><input type="text" name="email"></td>
												</tr>
												<tr>
													<td> <p>Message</p></td>
													<td><textarea name="message"></textarea></td>
												</tr>
												
											</table>
											<div class="snd-btn">
							<button onclick="return confirm('Message send Successfully')">Send Now</button>
						</div>
										</form>
									</div>
								</div>
							</div>
						</div>
						
					</div>
				</div>
				
				<div class="list-1">
					<ul>
						<li>HOME</li>
						<li>NEW PROJECT</li>
						<li>SPECIAL</li>
						<li>ALL PRODUCTS</li>
						<li>REVIEWS</li>
						<li>CONTACT</li>
						<li>FAQS</li>
					</ul>
				</div>
				<div class="footer-2">
					<p>Copyright <i class="fa fa-copyright" aria-hidden="true"></i>2013 Enest.Privacy Notice</p>
				</div>
			</div>
		</div>
	</div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/laravel/ecommerce/resources/views/contact.blade.php ENDPATH**/ ?>