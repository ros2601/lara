<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<div class="main-categorious">
			<div class="footer">
				<div class="categorious">
					<div class="cate-heading">
						<p>CATEGORIES</p>
					</div>
					<div class="items">
					<ul>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Dishwasher</li></a>
						<a href="<?php echo e(url('/tv')); ?>"><li>tvs</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Ranges</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Computer</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Blue Ray and DVD Player</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Projectors</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Hometheater System</li></a>
						<a href="<?php echo e(url('/camera')); ?>"><li>Camera</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Camcorders</li></a>
					    <a href="<?php echo e(url('/dishwasher')); ?>"><li>Washer & Dryers</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Refrigerators</li></a>
						<a href="<?php echo e(url('/dishwasher')); ?>"><li>Microwaves</li></a>
						</ul>
					</div>
				</div>
				<div class="contact">
				
				 
					<div class="contact-us" align="center">
						<p>Products</p>
					</div>
				  
					<?php $__currentLoopData = $product; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
		         
					<div class="dish-info">
                   
						<div class="machine-pic">
							<div class="img">
								<img src="images/<?php echo e($row->image); ?>">
							</div>
							<div class="stock">
								<p>In Stock: <?php echo e($row->stock); ?></p>
							</div>
						</div>
						<div class="machine-info">
							<div class="date">
								<span><?php echo e($row->date); ?></span>
							</div>
							<!-- <hr class="hr"> -->
							<div class="washer">
								<p><?php echo e($row->name); ?></p>
							</div>
							<div class="model-info">
								<span>Model: <?php echo e($row->model); ?></span>
								<p>Manufacturer: <?php echo e($row->manufacturer); ?></p>
							</div>
							<div class="price">
								<span>Rs.<?php echo e($row->price); ?></span>
							</div>

                        <form action="<?php echo e(url('show-product/'.$row->id)); ?>" method="post">
						<?php echo e(csrf_field()); ?>

							<div class="checkout">
								<input type="submit" name="buy" value="BUY NOW">
							</div>
                        </form>

						</div>

					</div>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


				</div>
				<div class="list-1">
					<ul>
						<li>HOME</li>
						<li>NEW PROJECT</li>
						<li>SPECIAL</li>
						<li>ALL PRODUCTS</li>
						<li>REVIEWS</li>
						<li>CONTACT</li>
						<li>FAQS</li>
					</ul>
				</div>
				<div class="footer-2">
					<p>Copyright <i class="fa fa-copyright" aria-hidden="true"></i>2013 Enest.Privacy Notice</p>
				</div>
			</div>
		</div>
	</div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/laravel/ecommerce/resources/views/dishwasher.blade.php ENDPATH**/ ?>