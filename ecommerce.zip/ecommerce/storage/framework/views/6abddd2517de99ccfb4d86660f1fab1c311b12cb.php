<?php echo $__env->make('header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
		<div class="main-categorious">
			<div class="footer">
			   
				<table class="table table-hover" >
                    <thead>
                        <tr>
                           <th>Login First to see items Added in Cart</th>
                          </tr>
                    </thead>
                <tbody>
				
                </table>
                      

			</div>
		</div>
	</div>
</body>
</html><?php /**PATH /opt/lampp/htdocs/laravel/ecommerce/resources/views/nocart.blade.php ENDPATH**/ ?>