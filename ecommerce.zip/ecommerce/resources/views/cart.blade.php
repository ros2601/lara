@include('header')
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/css/bootstrap.min.css" integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
<script src="https://cdn.jsdelivr.net/npm/bootstrap@4.0.0/dist/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
 
		<div class="main-categorious">
			<div class="footer">
			    <table class="table table-hover">
						<thead>
                           <tr>
                            <h1 align=center>My Cart</h1>
                          </tr>
                        </thead>
                </table>
				<table class="table table-hover">
                    <thead>
                        <tr>
                           <th scope="col">Name</th>
                           <th scope="col">Individual Price</th>
                           <th scope="col">Quanity</th>
                           <th scope="col">Total</th>
	                       <th scope="col">Remove</th>
                          </tr>
                    </thead>
                <tbody>
					@if($cart)
                    @foreach($cart as $row)
                    <tr>
                        <th scope="row">{{$row->name}}</th>
                        <td>{{$row->price}}</td>
	                    <td>{{$row->quantity}}</td>
                        <td>{{$row->total}}</td>
	                    <td><a href="{{url('/remove-item/'.$row->id)}}" onclick="return confirm('Item Deleted Successfully')">Remove</a></td>
                    </tr>
					@endforeach
					@endif
                </tbody>
                </table>
                  
			
					<div class="list-1">
					<ul>
						<li>HOME</li>
						<li>NEW PROJECT</li>
						<li>SPECIAL</li>
						<li>ALL PRODUCTS</li>
						<li>REVIEWS</li>
						<li>CONTACT</li>
						<li>FAQS</li>
					</ul>
				</div>
				<div class="footer-2">
					<p>Copyright <i class="fa fa-copyright" aria-hidden="true"></i>2013 Enest.Privacy Notice</p>
				</div>
			</div>
		</div>
	</div>
</body>
</html>