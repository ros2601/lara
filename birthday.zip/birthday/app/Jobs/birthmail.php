<?php

namespace App\Mail;

use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Mail\Mailable;
use Illuminate\Queue\SerializesModels;
use Mail;
use App\Models\people;
use App\Mail\BirthDayWish;

class birthday extends Mailable
{
    use Queueable, SerializesModels;

    public $user;
    public function __construct()
    {
        //
    }

    public function handle()
    { 
        // $i = 0;
        // $users = people::whereMonth('dob', '=', date('m'))
        //         ->whereDay('dob', '=', date('d'))
        //         ->get();  

        // if ($users->count() > 0)
        // {
        //     foreach ($users as $user)
        //     {
        //         Mail::to($user)->send(new BirthDayWish($user));
        //         $i++; 
        //     } 
        // }
        // return 0;
    }
}
