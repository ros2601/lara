<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Jobs\birthmail;
use App\Models\people;
class bcontroller extends Controller
{
    //--------------------------------------------------------------------------
    public function userregister(Request $request)
    {
    $add= new people;
    if($request->isMethod('post'))
    {
        $add->name=$request->get('name');
        $add->email=$request->get('email');
        $add->password=$request->get('password');
        $add->dob=$request->get('dob');
        $add->save();
        return back()->withErrors(["custom_name" => "Registration Successful !"]);
    }
    }
    //--------------------------------------------------------------------------
  
}
