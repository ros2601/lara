<!DOCTYPE html>
<html>
  <head>
    <title>Send Email Form</title>
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('http://localhost/assignment/resources/css/style.css')); ?>">
    <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500,700" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">
  </head>
  <body style=" background: linear-gradient(#facfcf, #9198e5);;">
 
    <div class="testbox" style="margin:5%;">
  
    <form method="post" action="<?php echo e(url('userregister')); ?>"  enctype="multipart/form-data"> 
        <?php echo e(csrf_field()); ?>

    <?php $__errorArgs = ['custom_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="form-group" style="text-align:center; color:black; background:pink; width:97%; padding:15px; border-radius:10px;">
        <b><?php echo e($message); ?></b>
        </div>
    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <br/>
      <div class="banner">
      <img src="bg.PNG" width=100% height=100%>
      </div>
      <div class="item">
      <div class="item">
        <p>Name:</p>
        <input type="text" name="name" placeholder="Your Name here"/>
      </div>
      <div class="item">
        <p>Email Address:</p>
        <input type="email" name="email" placeholder="Your Email Address here"/>
      </div>
      <div class="item">
        <p>Password:</p>
        <input type="password" name="password" placeholder="Your Password here"/>
      </div>
      <div class="item">
        <p>Select Your Date of Birth</p>
        <input type="date" name="dob"/>
      </div>
       <div class="btn-block" >
          <button type="submit" href="/" style="width:30%; background-color:green;">Send</button>
       </div>
    </form>

    </div>
  </body>
</html><?php /**PATH /opt/lampp/htdocs/birthday/resources/views/register.blade.php ENDPATH**/ ?>